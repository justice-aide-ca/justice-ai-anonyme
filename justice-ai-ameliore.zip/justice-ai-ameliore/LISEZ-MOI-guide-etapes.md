# Justice AI — Guide de déploiement pas à pas

## ✅ Ce qui a été amélioré

1. **Liens réparés** — les 2 liens morts (carta-pastorale1, le-bon-alignement-horizon) supprimés, les 2 liens obsolètes mis à jour (Carta Pastorale et Le Bon Alignement pointent maintenant vers les bonnes adresses).
2. **Partage sur les réseaux sociaux** — quand vous collerez le lien sur WhatsApp ou Facebook, une belle carte apparaîtra (balance dorée + « Assistance juridique gratuite et 100 % anonyme »).
3. **Favicon** — la petite balance dorée dans l'onglet du navigateur.
4. **3 nouvelles pages** — Confidentialité, Conditions, Contact (en 6 langues, comme le site).
5. **Sécurité renforcée** — la liste des demandes anonymes n'est plus publique (voir étape 4, très important).
6. **Google** — robots.txt et sitemap.xml ajoutés.

---

## Étape 1 — Ouvrir votre dépôt GitHub

1. Allez sur **github.com** et connectez-vous.
2. Ouvrez le dépôt **justice-ai-anonyme**.

## Étape 2 — Téléverser les nouveaux fichiers

1. Dans le dépôt, cliquez en haut à droite sur **Add file** → **Upload files**.
2. Ouvrez le dossier **A-GLISSER-SUR-GITHUB** sur votre ordinateur.
3. Glissez-déposez dans la page GitHub :
   - le dossier **public** (entier)
   - le fichier **server.js**
   - le fichier **.gitignore** (il est peut-être invisible : dans l'explorateur Windows, onglet *Affichage* → cochez *Éléments masqués*… ou tapez `.gitignore` dans la recherche du dossier)
4. Attendez la fin du téléversement, puis cliquez sur le bouton vert **Commit changes** (en bas).
5. GitHub remplacera les anciens fichiers par les nouveaux automatiquement.

## Étape 3 — Supprimer le fichier de données (vie privée) 🔒

Le dépôt contient actuellement les descriptions des demandes anonymes, visibles par tout le monde. Il faut le retirer :

1. Dans le dépôt, ouvrez le dossier **data**, puis le fichier **demandes.json**.
2. Cliquez sur les **trois points ⋯** en haut à droite → **Delete file**.
3. Cliquez sur **Commit changes**.

> Le serveur recréera un fichier vide tout seul au prochain démarrage. Les futures demandes ne seront plus publiées.

## Étape 4 — Créer le nouveau mot de passe admin (sur Render)

L'ancien mot de passe `justice2026` était visible publiquement sur GitHub. Il ne fonctionnera plus. Choisissez-en un nouveau :

1. Allez sur **dashboard.render.com** et connectez-vous.
2. Cliquez sur votre service **justice-ai-anonyme-2**.
3. Dans le menu de gauche, cliquez sur **Environment**.
4. Cliquez sur **Add Environment Variable** :
   - **Key** : `ADMIN_PASSWORD`
   - **Value** : un mot de passe de votre choix (exemple : `Balance-2026-Justice!`) — notez-le dans un endroit sûr, ne le partagez avec personne.
5. Cliquez sur **Save Changes**. Render redéploiera le site tout seul (2-3 minutes).

> Votre page admin sera désormais à l'adresse :
> `https://justice-ai-anonyme-2.onrender.com/admin?password=VOTRE-MOT-DE-PASSE`

## Étape 5 — Vérifier que tout fonctionne

Après quelques minutes, ouvrez :

- [ ] **https://justice-ai-anonyme-2.onrender.com/** — le site s'affiche normalement
- [ ] **/privacy** — la page Confidentialité s'ouvre (plus d'erreur 404)
- [ ] **/terms** — la page Conditions s'ouvre
- [ ] **/contact** — la page Contact s'ouvre
- [ ] Les 4 liens du bas (Amour & Vérité, Le Bon Alignement, ONBRIDGE AI, Carta Pastorale) ouvrent des sites qui fonctionnent
- [ ] Posez une question juridique test — l'IA répond toujours
- [ ] **Test WhatsApp** : collez le lien du site dans un message à vous-même — la carte avec la balance dorée apparaît ✨
- [ ] **/admin?password=VOTRE-MOT-DE-PASSE** — votre page admin s'ouvre

---

## ❓ En cas de souci

- **Le site ne change pas** → attendez 5 minutes (Render déploie), videz le cache (Ctrl + F5).
- **L'IA ne répond plus** → vérifiez que `OPENAI_API_KEY` existe toujours dans Render → Environment (elle n'a pas changé, mais autant vérifier).
- **L'admin refuse votre nouveau mot de passe** → revérifiez l'orthographe exacte dans Render → Environment (majuscules/minuscules comptent).

Si quelque chose bloque, dites-moi simplement à quelle étape et ce que vous voyez : on corrigera ensemble. 🙏
